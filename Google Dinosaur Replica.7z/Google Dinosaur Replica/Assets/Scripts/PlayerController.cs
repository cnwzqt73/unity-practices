using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerController : MonoBehaviour
{
    public float jumpForce = 12;
    private Rigidbody2D rb = null;
    private bool isGround = true;

    private bool canControl = true;

    private void Start()
    {
        if (GetComponent<Rigidbody2D>() != null)
        {
            rb = GetComponent<Rigidbody2D>();
        }
    }

    private void Update()
    {
        if (!canControl)
            return;

        if (Input.GetKeyDown(KeyCode.Space) && isGround)
            {
                Jump();
                isGround = false;
            }
    }

    private void Jump()
    {
        rb.linearVelocity = Vector2.up * jumpForce;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Ground"))
        {
            isGround = true;
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Obstacle"))
        {
            FindFirstObjectByType<ObstacleManager>().GameOver();
            GetComponent<Animator>().SetTrigger("Die");
            canControl = false;
            rb.linearVelocity = Vector2.zero;
            rb.bodyType = RigidbodyType2D.Kinematic; 
        }
    }
}
