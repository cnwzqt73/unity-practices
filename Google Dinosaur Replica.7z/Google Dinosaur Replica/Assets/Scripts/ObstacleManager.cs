using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

/* Game 窗口分辨率：1200 * 200 */

public class ObstacleManager : MonoBehaviour
{
    public float groundMoveSpeed = 20;

    public GameObject[] obstaclePrefabs;
    public Vector2 obstacleSpawnRateRange;
    private float obstacleSpawnRate;
    private float obstacleSpawnTimer;

    public GameObject cloudPrefab;
    public Vector2 cloudSpawnRateRange;
    private float cloudSpawnRate;
    private float cloudSpawnTimer;

    public TextMeshProUGUI scoreText;
    private float score;

    public GameObject retryButton;

    private void Start()
    {
        obstacleSpawnRate = Random.Range(obstacleSpawnRateRange.x, obstacleSpawnRateRange.y);
        cloudSpawnRate = Random.Range(cloudSpawnRateRange.x, cloudSpawnRateRange.y);

        retryButton.SetActive(false);
    }

    private void Update()
    {
        obstacleSpawnTimer += Time.deltaTime;
        if (obstacleSpawnTimer > obstacleSpawnRate)
        {
            SpawnNewObstacle();
            obstacleSpawnTimer = 0;
            obstacleSpawnRate = Random.Range(obstacleSpawnRateRange.x, obstacleSpawnRateRange.y);
        }

        cloudSpawnTimer += Time.deltaTime;
        if (cloudSpawnTimer > cloudSpawnRate)
        {
            SpawnNewCloud();
            cloudSpawnTimer = 0;
            cloudSpawnRate = Random.Range(cloudSpawnRateRange.x, cloudSpawnRateRange.y);
        }

        score += Time.deltaTime;
        string zero = "00000";
        scoreText.text = "SCORE: " + zero.Substring(0, zero.Length - ((int)score).ToString().Length) + (int)score;
    }

    private void SpawnNewObstacle()
    {
        var index = Random.Range(0, obstaclePrefabs.Length);
        var obstacle = Instantiate(obstaclePrefabs[index], transform);
        obstacle.transform.position = new Vector3(32f, -1.85f, 0);
    }

    private void SpawnNewCloud()
    {
        var cloud = Instantiate(cloudPrefab, transform);
        cloud.transform.position = new Vector3(32f, Random.Range(0, 3.5f), 0);
    }

    public void GameOver()
    {
        Time.timeScale = 0;
        retryButton.SetActive(true);
    }

    public void Retry()
    {
        Time.timeScale = 1;
        SceneManager.LoadScene(0);
    }
}
