using UnityEngine;

public class AutoMove : MonoBehaviour
{
    public Sprite[] obstacleImages;
    public bool isObstacle = false;
    private float moveSpeed = 0;

    private void Start()
    {
        moveSpeed = FindFirstObjectByType<ObstacleManager>().groundMoveSpeed;

        if (!isObstacle)
        {
            moveSpeed /= 5;
        }
        else
        {
            var index = Random.Range(0, obstacleImages.Length);
            GetComponent<SpriteRenderer>().sprite = obstacleImages[index];
        }

        Destroy(gameObject, 20f);
    }

    private void Update()
    {
        transform.position += Vector3.left * moveSpeed * Time.deltaTime;
    }
}