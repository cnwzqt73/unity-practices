using UnityEngine;

public class ScrollingBackground : MonoBehaviour
{
    private float moveSpeed = 20;

    private void Start()
    {
        moveSpeed = FindFirstObjectByType<ObstacleManager>().groundMoveSpeed;
    }

    private void Update()
    {
        transform.position += Vector3.left * moveSpeed * Time.deltaTime;

        if (transform.position.x < -93.75)
        {
            transform.position = new Vector3(93.75f, -3, 0);
        }
    }
}
