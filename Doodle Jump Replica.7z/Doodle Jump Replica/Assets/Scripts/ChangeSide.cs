using UnityEngine;

public class ChangeSide : MonoBehaviour
{
    // 偏移一点距离是为了不停地左右瞬移
    private void OnTriggerExit2D(Collider2D collision)
    {
        Transform t = collision.gameObject.transform;
        t.position = new Vector3((-t.position.x) * 0.95f, t.position.y, 0);
    }
}
