using UnityEngine;

public class LevelGenerator : MonoBehaviour
{
    public GameObject[] platformPrefabs;
    public float cameraHeight = 5.5f;
    public float currentYPos = 0f;
    public Transform platformPool;

    private void Start()
    {
        SpawnPlatformPool();

        while (currentYPos < Camera.main.transform.position.y + cameraHeight)
        {
            PickNewPlatform();
        }
    }

    private void Update()
    {
        if (currentYPos < Camera.main.transform.position.y + cameraHeight)
        {
            PickNewPlatform();
        }
    }

    private void SpawnPlatformPool()
    {
        int basicPlatformAmount = 30;
        int weakPlatformAmount = 12;

        for (int i = 0; i < basicPlatformAmount; i++)
        {
            var platform = Instantiate(platformPrefabs[0], platformPool);
            platform.SetActive(false);
        }

        for (int i = 0; i < weakPlatformAmount; i++)
        {
            var platform = Instantiate(platformPrefabs[1], platformPool);
            platform.SetActive(false);
        }
    }

    private void PickNewPlatform()
    {
        currentYPos += Random.Range(0.3f, 1f);
        float xPos = Random.Range(-3.8f, 3.8f);

        int r = 0;
        do
        {
            r = Random.Range(0, platformPool.childCount);
        } while (platformPool.GetChild(r).gameObject.activeInHierarchy);

        platformPool.GetChild(r).transform.position = new Vector2(xPos, currentYPos);
        platformPool.GetChild(r).gameObject.SetActive(true);
    }
}
