using UnityEngine;

public class Platform : MonoBehaviour
{

    public PlatformType platformType;
    public float bounceSpeed = 4f;

    private void OnCollisionEnter2D(Collision2D collision)
    {
        // Doodler 只有向下接触到 Platform 时才会产生弹跳
        // 避免 Dooldler 从侧面碰到 Platform 时被弹开
        if (collision.contacts[0].normal == Vector2.down)
        {
            if (collision.gameObject.TryGetComponent<Rigidbody2D>(out var rb))
            {
                rb.linearVelocity = Vector2.up * bounceSpeed;
            }

            if (platformType == PlatformType.weak)
            {
                GetComponent<Animator>().SetTrigger("Trigger");
                Invoke("HideGameObject", 0.4f);
            }
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.CompareTag("MainCamera"))
        {
            gameObject.SetActive(false);
        }
    }
    public void HideGameObject()
    {
        gameObject.SetActive(false);
    }
}

public enum PlatformType
{
    normal,
    weak
}