using UnityEngine;

public class BlockHolder : MonoBehaviour
{
    private int blockAmount;

    private void Start()
    {
        foreach (Transform child in transform)
        {
            if (!child.GetComponent<BlockNew>().isGoldBlock)
            {
                blockAmount++;
            }
        }
    }

    public void BlockGetDestroy()
    {
        blockAmount--;
        if (blockAmount <= 0)
        {
            print("You WIN");
        }
    }
}
