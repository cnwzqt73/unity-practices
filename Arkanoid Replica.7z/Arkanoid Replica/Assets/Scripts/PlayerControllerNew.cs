using UnityEngine;

/* Game 窗口尺寸 600 * 800*/
[RequireComponent(typeof(Rigidbody2D))]
public class PlayerControllerNew : MonoBehaviour
{
    public float playerMoveSpeed;
    public float ballShootSpeed;

    private Rigidbody2D rb;

    public Transform ballPos;
    public GameObject ballPrefab;
    private GameObject currentBall;
    private bool isPlaying = false;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();

        SpawnNewBall();
    }

    private void Update()
    {
        float h = Input.GetAxis("Horizontal");
        rb.linearVelocity = Vector2.right * h * playerMoveSpeed;

        var pos = transform.position;
        pos.x = Mathf.Clamp(pos.x, -2.8f, 2.8f);
        transform.position = pos;

        if (!isPlaying && Input.GetKeyDown(KeyCode.Space))
        {
            isPlaying = true;
            ShootBall();
        }
    }

    public void SpawnNewBall()
    {
        isPlaying = false;
        currentBall = Instantiate(ballPrefab, ballPos.position, ballPrefab.transform.rotation);
        currentBall.transform.parent = transform;
        currentBall.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Kinematic;
    }

    private void ShootBall()
    {
        currentBall.transform.parent = null;
        currentBall.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Dynamic;
        currentBall.GetComponent<Rigidbody2D>().linearVelocity = new Vector2(Random.Range(-1f, 1f), 1).normalized * ballShootSpeed;
    }
}
