using UnityEngine;

public class AnimationEventNew : MonoBehaviour
{
    public void DestroyAfterAnimation()
    {
        Destroy(gameObject);
    }
}
