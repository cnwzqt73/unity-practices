using UnityEngine;

public class BlockNew : MonoBehaviour
{
    public GameObject exploPrefab;
    public bool isGoldBlock;
    public int maxHp = 1;
    private int hp = 0;


    private void Start()
    {
        hp = maxHp;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (isGoldBlock)
            return;

        hp--;
        if (hp <= 0)
        {
            Destroy(gameObject);
            Instantiate(exploPrefab, transform.position, Quaternion.identity);
        }
    }
}
