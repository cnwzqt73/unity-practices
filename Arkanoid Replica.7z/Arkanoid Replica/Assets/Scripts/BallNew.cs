using UnityEngine;

public class BallNew : MonoBehaviour
{
    private Rigidbody2D rb;
    private float playerV;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        playerV = FindFirstObjectByType<PlayerControllerNew>().ballShootSpeed;
        rb.linearDamping = 0;
  
    }

    private void FixedUpdate()
    {
        float v = rb.linearVelocity.magnitude;

        if (v != playerV)
        {
            var velocity = rb.linearVelocity;
            rb.linearVelocity = velocity * (playerV / v);
        }
    }
}
